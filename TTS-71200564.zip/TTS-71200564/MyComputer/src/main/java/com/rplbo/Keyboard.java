package com.rplbo;

public class Keyboard {
    private String key;
}