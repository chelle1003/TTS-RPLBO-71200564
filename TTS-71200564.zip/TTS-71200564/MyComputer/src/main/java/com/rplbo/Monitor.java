package com.rplbo;

public class Monitor {
    public void display(Storage storage){
        storage.toString();
    }
}
