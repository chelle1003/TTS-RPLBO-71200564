package com.rplbo;

public class TouchScreen {
    public void display(Storage storage){
        storage.toString();
    }
}